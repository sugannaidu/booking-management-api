package com.appservices.booking.service;

public interface BookSystemConfigurator {
     void initializeData();
}
