package com.appservices.booking;

import com.appservices.booking.data.entity.*;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.ComponentScans;

//@ComponentScan(basePackageClasses = {Booking.class, BookedTimeslot.class, BookingUser.class, MeetingRoom.class, TimeSlot.class})
@SpringBootApplication
public class BookingApplication {

	public static void main(String[] args) {
		SpringApplication.run(BookingApplication.class, args);
	}

}
